<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
	export default{
		data(){
			return {
				list2:[],
				list3:[],
				list4:[],
				list5:[],
				list6:[],
				list7:[],
				list8:[],
				list9:[],
				list10:[],
				list11:[],
				list12:[],
				listz:[],
				la_id: "",
				nowurl: "",
			}
		},
		created() {
			// this.linktab();
			this.$axios.all([
				this.$axios.get('api/book-list/533ea342b774950c04000189'),
				this.$axios.get('api/book-list/5454ccfdbd7c68e31be5577e'),
				this.$axios.get('api/book-list/576d182926e661a62719a1b6'),
				this.$axios.get('api/book-list/57331505025ffaa06cb28852'),
				this.$axios.get('api/book-list/561bf778359a855538e39485'),
				this.$axios.get('api/book-list/533c2eeb6fcc37c139006cf8'),
				this.$axios.get('api/book-list/5943d2a4253e111d4e8906ae'),
				this.$axios.get('api/book-list/5552b1c64df956f918dc4991'),
				this.$axios.get('api/book-list/5c40574e2d25940001d3fa57'),
				this.$axios.get('api/book-list/5604e265778ffc605a834de1'),
				this.$axios.get('api/book-list/54263829d1564bf615448769')
			]).then((res)=>{
				
				if(res[0].status==200&&res[1].status==200&&res[2].status==200){
					this.list2=res[0].data.bookList.books;
					this.list3=res[1].data.bookList.books;
					this.list4=res[2].data.bookList.books;
					this.list5=res[3].data.bookList.books;
					this.list6=res[4].data.bookList.books;
					this.list7=res[5].data.bookList.books;
					this.list8=res[6].data.bookList.books;
					this.list9=res[7].data.bookList.books;
					this.list10=res[8].data.bookList.books;
					this.list11=res[9].data.bookList.books;
					this.list12=res[10].data.bookList.books;
					this.listz = [...this.list2,...this.list3,...this.list4,...this.list5,...this.list6,...this.list7,...this.list8,...this.list9,...this.list10,...this.list11,...this.list12]
					this.$store.commit('serPrint',this.listz)
					console.log(this.listz)
				}
			}).catch((error)=>{
				console.log(error)
			})
		},
		methods:{
			linktab() {
			    //   let goUrl = this.isMobile();
			    //   if (goUrl === 1) {
			    //     //移动端地址
			    //     // location = "http://127.0.0.1:8043";
			    //   } else {
			    //     //PC地址
			    //     location = "http://172.17.162.12:8080/home";
			    //   }
			    // },
			    // isMobile() {
			    //   let flag = navigator.userAgent.match(
			    //     /(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i
			    //   );
			    //   let goUrl = flag ? 1 : 0;
			    //   return goUrl;
			    },
		}
	}
</script>
<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

nav {
  padding: 30px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}

nav a.router-link-exact-active {
  color: #42b983;
}
</style>
