<template>
	<div class="h6">
		<el-menu background-color="#d9defe"  class="el-menu-demo" mode="horizontal">
			<el-menu-item index="1"><router-link to="/BooksNew">首页</router-link></el-menu-item>
			<el-menu-item index="2"><router-link to="/catory" >分类</router-link></el-menu-item>
			<el-menu-item index="3"><router-link to="/书单">书单</router-link></el-menu-item>
			<el-menu-item index="4"><router-link to="/排行榜">首页</router-link></el-menu-item>
		</el-menu>
	</div>
</template>

<script>
</script>

<style>
</style>
