const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
  lintOnSave:false,
  devServer:{
  	  proxy:{
  		  '/api':{
  			  target:'https://api.zhuishushenqi.com',
  		      changOrigin:true,
			  secure:true,
			  pathRewrite:{
				  '^/api':'/'
			  }
  		  },
		  '/www':{
		      target:'https://www.zhuishushenqi.com',
		      changOrigin:true,
		  	  pathRewrite:{
		  	     '^/www':'/'
		  	  }
		  },
		  '/jiek':{
		      target:'https://111.229.37.167',
		      changOrigin:true,
		  	  pathRewrite:{
		  	     '^/':'/'
		  	  }
		  }
  	  }
  }
})
